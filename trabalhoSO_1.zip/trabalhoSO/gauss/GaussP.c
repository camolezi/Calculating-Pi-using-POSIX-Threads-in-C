#include<stdio.h>
#include<gmp.h>
#include <math.h>
#include <stdlib.h>
#include <pthread.h>


mpf_t a0, b0, t0, p0,aux,aN,bN,tN,pN,pi;
pthread_t a,b,c,d;

long long int contadorPrograma = 0;
int  fimIt = 0;

#define numeroIt 100000


void * funcA(void * a){
    //An+1

    long long int contadorLocal = contadorPrograma -1;
    while(1){
        if(contadorLocal < contadorPrograma){
            mpf_add(aN,a0,b0);
            mpf_div_ui(aN,aN,2);

            //Tn+1 que depede de An+1
            mpf_sub(tN,a0,aN);
            mpf_pow_ui(tN,tN,2);
            mpf_mul(tN,tN,p0);
            mpf_sub(tN,t0,tN);

            contadorLocal++;
            fimIt++;

        }
        if(contadorLocal == numeroIt-1){
            pthread_exit(NULL);
        }

    }


}

void * funcB(void * b){
    //Bn+1
    long long int contadorLocal = contadorPrograma -1;
    while(1){
        if(contadorLocal < contadorPrograma){
            mpf_mul(bN,a0,b0);
            mpf_sqrt(bN,bN);
            contadorLocal++;
            fimIt++;

        }
        if(contadorLocal == numeroIt-1){
            pthread_exit(NULL);
        }
    }



}

void * funcP(void * p){
    //Pn+1
    long long int contadorLocal = contadorPrograma -1;
    while(1){
        if(contadorLocal < contadorPrograma){
            mpf_add(pN,p0,p0);
            contadorLocal++;
            fimIt++;

        }
        if(contadorLocal == numeroIt-1){
            pthread_exit(NULL);
        }
    }
}

//Thread que controla o número de iterações e a sincroniza as outras threads com variaveis auxiliares
void * contador(void *c){
    while(1){

        if(fimIt == 3){
            //printf("Entrou");
            mpf_set(a0,aN);
            mpf_set(b0,bN);
            mpf_set(t0,tN);
            mpf_set(p0,pN);
            fimIt = 0;
            contadorPrograma++;
            if(contadorPrograma == numeroIt ){
                pthread_exit(NULL);
            }
        }


    }

}



int main(){

    mpf_set_default_prec(100000);

    //Declara e inicializa as valores

    mpf_init (aux);
    mpf_init (a0);
    mpf_init (b0);
    mpf_init (t0);
    mpf_init (p0);

    mpf_init (aN);
    mpf_init (bN);
    mpf_init (tN);
    mpf_init (pN);
    mpf_init (pi);


    //valores inicias
    mpf_set_d(a0,1.0);
    mpf_set_d(b0,1.0/sqrt(2.0));
    mpf_set_d(t0, 0.25);
    mpf_set_d(p0, 1);


    pthread_create(&a,NULL, funcA,NULL);
    pthread_create(&b,NULL,funcB ,NULL);
    pthread_create(&c, NULL,funcP , NULL);
    pthread_create(&d, NULL, contador, NULL);

    void * teste;
    pthread_join(d,&teste);

    //Calculo do pi
    mpf_add(pi,aN,bN);
    mpf_pow_ui(pi,pi,2);
    mpf_mul_ui(aux,tN,4);
    mpf_div(pi,pi,aux);

    //Print na saida padrão
    mpf_out_str(stdout,10,0,pi);
    return 0;
}
