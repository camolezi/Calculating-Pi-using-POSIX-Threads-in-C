#include<stdio.h>
#include<gmp.h>
#include <math.h>
#include <stdlib.h>

int main(){

    long long int x = 0;
    long long int numeroIt = 100000;
    //Precisão padrão
    mpf_set_default_prec(100000);

    //Declara e inicializa as valores
    mpf_t a0, b0, t0, p0,aux,aN,bN,tN,pN,pi;
    mpf_init (aux);
    mpf_init (a0);
    mpf_init (b0);
    mpf_init (t0);
    mpf_init (p0);

    mpf_init (aN);
    mpf_init (bN);
    mpf_init (tN);
    mpf_init (pN);
    mpf_init (pi);



    //valores inicias
    mpf_set_d(a0,1.0);
    mpf_set_d(b0,1.0/sqrt(2.0));
    mpf_set_d(t0, 0.25);
    mpf_set_d(p0, 1);

    for(x = 0; x < numeroIt; x++){

        //An+1
        mpf_add(aux,a0,b0);
        mpf_div_ui(aN,aux,2);

        //Bn+1
        mpf_mul(aux,a0,b0);
        mpf_sqrt(bN,aux);

        //Pn+1
        mpf_add(pN,p0,p0);

        //Tn+1
        mpf_sub(aux,a0,aN);
        mpf_pow_ui(aux,aux,2);
        mpf_mul(aux,aux,p0);
        mpf_sub(tN,t0,aux);

        //Seta o novo an para a proxima interação
        mpf_set(a0,aN);
        mpf_set(b0,bN);
        mpf_set(t0,tN);
        mpf_set(p0,pN);
    }

    //Calculo do pi
    mpf_add(pi,aN,bN);
    mpf_pow_ui(pi,pi,2);
    mpf_mul_ui(aux,tN,4);
    mpf_div(pi,pi,aux);

    //Print na saida padrão
    mpf_out_str(stdout,10,0,pi);

    return 0;
}
