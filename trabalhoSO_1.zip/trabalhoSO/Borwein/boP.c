#include<stdio.h>
#include<gmp.h>
#include <math.h>
#include <stdlib.h>
#include <pthread.h>


//Variaveis do programa
pthread_t a,b,c,d;
mpf_t c4,c2,c1,c16,piTotal;

long long int contadorPrograma = 0;
int  fimIt = 0;

#define numeroIt 100000
pthread_mutex_t mutex;

//Thread 
void * func(void * inicialP){

    long long int k;
    long long int inicial = * (long long int *)inicialP;
    mpf_t aux2,aux1;
    mpf_t pi;

    mpf_init (aux1);
    mpf_init (aux2);
    mpf_init (pi);

    mpf_set_d(pi,0.0);

    for(k = inicial; k < inicial + (numeroIt/4); k++){

        mpf_div_ui(aux1,c4,(8*k) + 1);
        mpf_div_ui(aux2,c2,(8*k) + 4);
        mpf_sub(aux1,aux1,aux2);

        mpf_div_ui(aux2,c1,(8*k) + 5);
        mpf_sub(aux1,aux1,aux2);

        mpf_div_ui(aux2,c1,(8*k) + 6);
        mpf_sub(aux1,aux1,aux2);

        mpf_pow_ui(aux2,c16,k);
        mpf_div(aux2,c1,aux2);

        mpf_mul(aux1,aux1,aux2);

        mpf_add(pi,pi,aux1);
    }

    //Adiciona o valor obtido localmente para a váriavel global que representa PI. Utilizando um mutex para garantir a segurança(evitar race condition);
    pthread_mutex_lock (&mutex);
    mpf_add(piTotal,piTotal,pi);
    pthread_mutex_unlock (&mutex);

    pthread_exit(NULL);

}


int main(){

    pthread_mutex_init(&mutex, NULL);

    //Precisão padrão
    mpf_set_default_prec(100000);

    mpf_init (c4);
    mpf_init (c2);
    mpf_init (c1);
    mpf_init (c16);
    mpf_init (piTotal);
    
    //Seta is valores da constantes como variaveis da biblioteca big number para facilitar os calculos
    mpf_set_d(c4,4.0);
    mpf_set_d(c2,2.0);
    mpf_set_d(c1,1.0);
    mpf_set_d(c16,16.0);
    mpf_set_d(piTotal,0.0);
    
    //Os valosres inciias de K para cada thread
    long long int k1,k2,k3,k4;
    k1 = 0;
    k2 = numeroIt/4;
    k3 = 2*(numeroIt/4);
    k4 = 3 *(numeroIt/4);

    pthread_create(&a, NULL , func, &k1);
    pthread_create(&b,NULL,func , &k2);
    pthread_create(&c, NULL,func , &k3);
    pthread_create(&d, NULL, func, &k4);


    pthread_join(a,NULL);
    pthread_join(b,NULL);
    pthread_join(c,NULL);
    pthread_join(d,NULL);

    //Print na saida padrão
    mpf_out_str(stdout,10,0,piTotal);

    return 0;
}

