#include<stdio.h>
#include<gmp.h>
#include <math.h>
#include <stdlib.h>

int main(){
    //Nùmero de interações
    long long int numeroIt = 100000;
    long long int k  = 0;
    //Precisão padrão
    mpf_set_default_prec(100000);

    //Declara e inicializa as valor
    //Constante:
    mpf_t c4,c2,c1,c16,aux2,aux1,pi;

    mpf_init (c4);
    mpf_init (c2);
    mpf_init (c1);
    mpf_init (c16);
    mpf_init (aux1);
    mpf_init (aux2);
    mpf_init (pi);


    mpf_set_d(c4,4.0);
    mpf_set_d(c2,2.0);
    mpf_set_d(c1,1.0);
    mpf_set_d(c16,16.0);
    mpf_set_d(pi,0.0);

    //Faz os cálculos das fórmulas
    for(k = 0; k < numeroIt; k++){

        mpf_div_ui(aux1,c4,(8*k) + 1);
        mpf_div_ui(aux2,c2,(8*k) + 4);
        mpf_sub(aux1,aux1,aux2);

        mpf_div_ui(aux2,c1,(8*k) + 5);
        mpf_sub(aux1,aux1,aux2);

        mpf_div_ui(aux2,c1,(8*k) + 6);
        mpf_sub(aux1,aux1,aux2);

        mpf_pow_ui(aux2,c16,k);
        mpf_div(aux2,c1,aux2);

        mpf_mul(aux1,aux1,aux2);

        mpf_add(pi,pi,aux1);
    }

    //Print na saida padrão
    mpf_out_str(stdout,10,0,pi);

    return 0;
}
