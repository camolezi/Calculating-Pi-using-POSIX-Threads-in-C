#include<stdio.h>
#include<gmp.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>


#define numeroIt 1000000000

int pontoDentroCirculo(double x , double y){
    double raio = x*x + y*y;
    if(raio <= 1){
        return 1;
    }else{
        return 0;
    }
}

int main(){

    //seed aleatoria
    srand ( time ( NULL));

    //auxiliares
    long long int x;
    long long int pointsInsideCircle = 0;

    //Precisão dos bigNumbers
    mpf_set_default_prec(10000);

    mpf_t pi;

    mpf_init(pi);

    double pX;
    double pY;

    for(x = 0; x < numeroIt; x++){
        
        //Sorteia coordenas X e Y entre [0,1]
        pX = (double)rand()/RAND_MAX;
        pY = (double)rand()/RAND_MAX;
        
        //Conta quantos pontis estão dentro do circulo
        if(pontoDentroCirculo(pX,pY) == 1){
            pointsInsideCircle++;
        }
    }
    
    //Calcula PI
    mpf_set_ui(pi,pointsInsideCircle);
    mpf_div_ui(pi,pi,numeroIt);
    mpf_mul_ui(pi,pi,4);

    mpf_out_str(stdout,10,0,pi);

    return 0;
}



