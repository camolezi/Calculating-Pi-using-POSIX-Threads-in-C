#include<stdio.h>
#include<gmp.h>
#include <math.h>
#include <stdlib.h>
#include <pthread.h>

#define numeroIt 1000000000

pthread_mutex_t mutex;
long long int totalInside = 0;


int pontoDentroCirculo(double x , double y){
    double raio = x*x + y*y;
    if(raio <= 1){
        return 1;
    }else{
        return 0;
    }
}

//Função RAND para poder ser acessada de várias thread diferentes
double randD(long long int * next){
    *next = *next * 1103515245 + 12345;
    return ((unsigned int)(*next/65536) % 32768)/32768.0;
}

void * pontoDentroCirculo_T(void * a){

    long long int next = time(NULL);
    long long int x;
    long long int pointsInsideCircle = 0;

    double pX;
    double pY;
    
    //Executa 1/4 dos pontos e depois coma na variavel global
    for(x = 0; x < (numeroIt/4); x++){

        pX = randD(&next);
        pY = randD(&next);

        if(pontoDentroCirculo(pX,pY) == 1){
            pointsInsideCircle++;
        }

    }

    pthread_mutex_lock (&mutex);
    totalInside += pointsInsideCircle;
    pthread_mutex_unlock (&mutex);

    pthread_exit(NULL);
}


int main(){

    mpf_set_default_prec(100);
    mpf_t pi;
    mpf_init(pi);


    pthread_mutex_init(&mutex, NULL);

    pthread_t a,b,c,d;

    pthread_create(&a, NULL , pontoDentroCirculo_T, NULL);
    pthread_create(&b, NULL , pontoDentroCirculo_T, NULL);
    pthread_create(&c, NULL , pontoDentroCirculo_T, NULL);
    pthread_create(&d, NULL , pontoDentroCirculo_T, NULL);



    pthread_join(a,NULL);
    pthread_join(b,NULL);
    pthread_join(c,NULL);
    pthread_join(d,NULL);


    mpf_set_ui(pi,totalInside);
    mpf_div_ui(pi,pi,numeroIt);
    mpf_mul_ui(pi,pi,4);

    mpf_out_str(stdout,10,0,pi);

    pthread_mutex_destroy(&mutex);

    return 0;
}

